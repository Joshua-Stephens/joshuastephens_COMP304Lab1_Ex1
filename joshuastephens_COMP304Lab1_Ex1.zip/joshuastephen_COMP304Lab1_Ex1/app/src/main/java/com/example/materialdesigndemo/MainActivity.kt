package com.example.materialdesigndemo;

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*

data class Note(
    var title: String,
    var content: String
)

class MainActivity : ComponentActivity() {
    private val notes = mutableStateListOf<Note>() // Manage notes here

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            QuickNotesApp()
        }
    }

    @Composable
    fun QuickNotesApp() {
        val navController = rememberNavController()
        NavHost(navController, startDestination = "home") {
            composable("home") { HomeScreen(navController, notes) }
            composable("create") { CreateNoteScreen(navController, notes) }
            composable("edit/{noteIndex}") { backStackEntry ->
                val noteIndex = backStackEntry.arguments?.getString("noteIndex")?.toInt()
                ViewEditNoteScreen(navController, noteIndex, notes)
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun HomeScreen(navController: NavHostController, notes: MutableList<Note>) {
        Scaffold(
            topBar = { TopAppBar(
                title = { Text("QuickNotes")},
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Cyan
                )

            )},
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    navController.navigate("create")
                }) {
                    Text("+")
                }
            }
        ) { paddingValues ->
            LazyColumn(modifier = Modifier.padding(paddingValues)) {
                itemsIndexed(notes) { index, note ->
                    Card(
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = note.title, style = MaterialTheme.typography.titleMedium)
                            Text(text = note.content.take(50) + "...", style = MaterialTheme.typography.bodyMedium)
                            Button(onClick = { navController.navigate("edit/$index") }) {
                                Text("Edit")
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun CreateNoteScreen(navController: NavHostController, notes: MutableList<Note>) {
        var title by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }

        Column(modifier = Modifier.padding(16.dp)) {
            TextField(value = title, onValueChange = { title = it }, label = { Text("Title") })
            TextField(value = content, onValueChange = { content = it }, label = { Text("Content") }, modifier = Modifier.weight(1f))
            Button(onClick = {
                // Add the new note to the list
                notes.add(Note(title, content))
                navController.navigate("home")
            }) {
                Text("Save")
            }
        }
    }

    @Composable
    fun ViewEditNoteScreen(navController: NavHostController, noteIndex: Int?, notes: MutableList<Note>) {
        if (noteIndex != null) {
            val note = notes[noteIndex]
            var title by remember { mutableStateOf(note.title) }
            var content by remember { mutableStateOf(note.content) }

            Column(modifier = Modifier.padding(16.dp)) {
                TextField(value = title, onValueChange = { title = it }, label = { Text("Title") })
                TextField(value = content, onValueChange = { content = it }, label = { Text("Content") }, modifier = Modifier.weight(1f))
                Button(onClick = {
                    // Update the note
                    notes[noteIndex] = Note(title, content)
                    navController.navigate("home")
                }) {
                    Text("Save")
                }
            }
        }
    }
}



